function criticalSize = facts (gamma,beta,t,i_sol,calendarTime)
    gamma %fact
    beta %fact
    mostInfectedPrediction = max(i_sol) %fact
    indexMostInfected = find(i_sol == mostInfectedPrediction); 
    timeMostInfectedPrediction = t(indexMostInfected)
    dateMostInfectedPrediction = calendarTime(1) + days(timeMostInfectedPrediction) %fact
    criticalSize = gamma/beta %fact
    infectionLength = 1/gamma %fact
end