package com.git_er_done.cmput301f22t06_team_project.interfaces;


/**
 * Interface for handling ShoppingListRecyclerView user interaction
 */
public interface ShoppingListRecyclerViewInterface {
    void onItemLongClick(int position);
}
