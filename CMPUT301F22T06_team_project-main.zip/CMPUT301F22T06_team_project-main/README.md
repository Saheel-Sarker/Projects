# CMPUT301F22T06_team_project
Meal planning app created by 6 group members in CMPUT301 , Fall 2022

TEST README
